-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 30, 2019 at 03:18 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `marketplace`
--

-- --------------------------------------------------------

--
-- Table structure for table `Admin`
--

CREATE TABLE `Admin` (
  `AdminUserID` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Admin`
--

INSERT INTO `Admin` (`AdminUserID`) VALUES
('karp');

-- --------------------------------------------------------

--
-- Table structure for table `Cart`
--

CREATE TABLE `Cart` (
  `Product_Name` varchar(225) NOT NULL,
  `Price` decimal(25,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Customer`
--

CREATE TABLE `Customer` (
  `Fname` varchar(50) NOT NULL,
  `Lname` varchar(50) NOT NULL,
  `User_Id` varchar(11) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(225) NOT NULL,
  `Phone_Num` varchar(15) NOT NULL,
  `Address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Customer`
--

INSERT INTO `Customer` (`Fname`, `Lname`, `User_Id`, `Email`, `Password`, `Phone_Num`, `Address`) VALUES
('Austen', 'Medina', 'ast86799', 'austenm25@gmail.com', '$2y$10$qC9vU1oD/xorDaHluObk0O4uFzaUMq1OJJ1nxkyWv8RNY/AUqk522', '6155001629', '4848 hay st'),
('john', 'smith', 'jsmith', 'randomemail@gmail.com', '$2y$10$AVxW91oAYE67JVTDeu7Zk.H0YJ0VbYy1GErfWV50VYmSPMxO2WUeW', '1234568921', '100 Random rd'),
('Spencer', 'Karpinsky', 'karp', 'Spencerk1999@gmail.com', '$2y$10$Nq2f6wO06V13S/kH6QtEQOnb.LIK.rU9DmCX04yFnfOGl1NcappLu', '14198921', '9502 Dabney Carr Dr'),
('test', 'test', 'test', 'sdk0567@gmail.com', '$2y$10$3Cn9eVxPNJRi5CTs93c7Ou6D0o169tzAzju4SwzceAmMyzh6keYAm', '123452', 'asdfasdf');

-- --------------------------------------------------------

--
-- Table structure for table `Orders`
--

CREATE TABLE `Orders` (
  `User_Id` varchar(50) NOT NULL,
  `Order_Num` int(50) NOT NULL,
  `Total_Price` decimal(25,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Product`
--

CREATE TABLE `Product` (
  `Product_ID` int(255) NOT NULL,
  `Product_Name` varchar(225) NOT NULL,
  `Manufacture` varchar(225) NOT NULL,
  `Quantity` int(50) NOT NULL,
  `Price` decimal(25,2) NOT NULL,
  `Description` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Product`
--

INSERT INTO `Product` (`Product_ID`, `Product_Name`, `Manufacture`, `Quantity`, `Price`, `Description`) VALUES
(2, 'test2', 'rand', 68, '40.00', 'test'),
(3, 'test', 'quan', 0, '50.00', 'test'),
(4, 'Backpack', 'Patagonia', 30, '110.00', 'Sturdy Backpack for camping'),
(5, 'Pockect knife', 'Benchmade', 3, '220.00', 'Griptilian'),
(6, 'Hammock', 'Eno', 6, '75.00', 'Great for sleeping'),
(7, 'Better Hammock', 'Bear Butt', 2, '50.00', 'Sturdy cheap hammock');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Admin`
--
ALTER TABLE `Admin`
  ADD PRIMARY KEY (`AdminUserID`);

--
-- Indexes for table `Customer`
--
ALTER TABLE `Customer`
  ADD PRIMARY KEY (`User_Id`);

--
-- Indexes for table `Orders`
--
ALTER TABLE `Orders`
  ADD PRIMARY KEY (`Order_Num`);

--
-- Indexes for table `Product`
--
ALTER TABLE `Product`
  ADD PRIMARY KEY (`Product_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Orders`
--
ALTER TABLE `Orders`
  MODIFY `Order_Num` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Product`
--
ALTER TABLE `Product`
  MODIFY `Product_ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
